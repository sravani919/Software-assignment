'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { ArrowLeft, Cloud, Headphones, Pause, Play, RotateCcw, Volume2, VolumeX, Waves, Wind, Zap } from 'lucide-react'

type MoodId = 'calm' | 'happy' | 'energetic' | 'focused' | 'sleepy' | 'melancholy'

type Mood = {
  id: MoodId
  name: string
  note: string
  message: string
  detail: string
  symbol: string
  colors: string
  timer?: number
}

const moods: Mood[] = [
  { id: 'calm', name: 'Calm', note: 'soften the edges', message: 'Let the world move around you.', detail: 'A quiet pocket of stillness, made just for you.', symbol: '◒', colors: 'from-slate-900 via-sky-950 to-teal-950', timer: 300 },
  { id: 'happy', name: 'Happy', note: 'find your light', message: 'There is so much good here.', detail: 'Follow the little sparks. They know the way.', symbol: '✦', colors: 'from-amber-200 via-orange-300 to-rose-400' },
  { id: 'energetic', name: 'Energetic', note: 'turn it up', message: 'You are made of momentum.', detail: 'Catch the current and let it carry you forward.', symbol: 'ϟ', colors: 'from-indigo-950 via-fuchsia-950 to-black' },
  { id: 'focused', name: 'Focused', note: 'one thing at a time', message: 'Make space for what matters.', detail: 'A clear desk. A clear mind. A small beginning.', symbol: '⌁', colors: 'from-stone-100 via-slate-100 to-stone-200', timer: 1500 },
  { id: 'sleepy', name: 'Sleepy', note: 'drift a little', message: 'Nothing needs your attention tonight.', detail: 'Rest is not an ending. It is a return.', symbol: '☾', colors: 'from-indigo-950 via-blue-950 to-slate-950', timer: 900 },
  { id: 'melancholy', name: 'Melancholy', note: 'feel it fully', message: 'Some feelings deserve a little rain.', detail: 'You do not have to rush through the weather.', symbol: '⌇', colors: 'from-slate-950 via-zinc-900 to-slate-950', timer: 600 },
]

function formatTime(seconds: number) {
  const minutes = Math.floor(seconds / 60).toString().padStart(2, '0')
  const remainder = (seconds % 60).toString().padStart(2, '0')
  return `${minutes}:${remainder}`
}

export default function Page() {
  const [selected, setSelected] = useState<MoodId | null>(null)
  const [soundOn, setSoundOn] = useState(false)
  const [isPlaying, setIsPlaying] = useState(false)
  const [timeLeft, setTimeLeft] = useState(0)
  const audioContext = useRef<AudioContext | null>(null)
  const oscillator = useRef<OscillatorNode | null>(null)

  const mood = useMemo(() => moods.find((item) => item.id === selected) ?? null, [selected])

  useEffect(() => {
    if (!isPlaying || timeLeft <= 0) return
    const interval = window.setInterval(() => setTimeLeft((time) => Math.max(0, time - 1)), 1000)
    return () => window.clearInterval(interval)
  }, [isPlaying, timeLeft])

  useEffect(() => () => {
    oscillator.current?.stop()
    audioContext.current?.close()
  }, [])

  function chooseMood(id: MoodId) {
    const next = moods.find((item) => item.id === id)
    setSelected(id)
    setIsPlaying(false)
    setTimeLeft(next?.timer ?? 0)
  }

  function toggleSound() {
    if (soundOn) {
      oscillator.current?.stop()
      oscillator.current = null
      setSoundOn(false)
      return
    }
    const AudioContextClass = window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext
    if (!AudioContextClass) return
    const context = new AudioContextClass()
    const node = context.createOscillator()
    const gain = context.createGain()
    node.type = 'sine'
    node.frequency.value = selected === 'energetic' ? 110 : selected === 'happy' ? 392 : 196
    gain.gain.value = 0.018
    node.connect(gain).connect(context.destination)
    node.start()
    audioContext.current = context
    oscillator.current = node
    setSoundOn(true)
  }

  function resetTimer() {
    setIsPlaying(false)
    setTimeLeft(mood?.timer ?? 0)
  }

  return (
    <main className={`moodscape ${selected ? `scene-${selected}` : 'scene-home'}`}>
      <div className="grain" aria-hidden="true" />
      {selected && <SceneDecor mood={selected} />}

      <header className="topbar">
        <button className="brand" onClick={() => setSelected(null)} aria-label="Return to mood selection">
          <span className="brand-mark">M</span><span>MoodScape</span>
        </button>
        <div className="topbar-right">
          <span className="live-dot" /> <span>an inner weather report</span>
          {selected && <button className="icon-button" onClick={toggleSound} aria-label={soundOn ? 'Turn ambience off' : 'Turn ambience on'}>{soundOn ? <Volume2 size={16} /> : <VolumeX size={16} />}</button>}
        </div>
      </header>

      {!selected ? (
        <section className="landing" aria-labelledby="mood-question">
          <div className="eyebrow"><span>01</span><span className="eyebrow-line" /><span>choose your atmosphere</span></div>
          <h1 id="mood-question">How are you<br /><em>feeling</em> right now?</h1>
          <p className="intro">A small world, tuned to your frequency.<br />No right answers. Just notice what calls to you.</p>
          <div className="mood-grid">
            {moods.map((item, index) => (
              <button key={item.id} className={`mood-card mood-${item.id}`} onClick={() => chooseMood(item.id)}>
                <span className="mood-number">0{index + 1}</span><span className="mood-symbol">{item.symbol}</span><span className="mood-name">{item.name}</span><span className="mood-note">{item.note}</span><span className="card-arrow">↗</span>
              </button>
            ))}
          </div>
          <div className="scroll-hint"><span className="scroll-line" /> hover to explore</div>
        </section>
      ) : (
        <section className="scene-content" aria-live="polite">
          <div className="scene-copy">
            <div className="eyebrow"><span>your atmosphere</span><span className="eyebrow-line" /><span>{mood.name}</span></div>
            <h1>{mood.message}</h1>
            <p>{mood.detail}</p>
            <div className="scene-actions">
              <button className="glass-button" onClick={() => setSelected(null)}><ArrowLeft size={15} /> Change mood</button>
              <button className={`glass-button sound-button ${soundOn ? 'active' : ''}`} onClick={toggleSound}>{soundOn ? <Volume2 size={15} /> : <Headphones size={15} />} {soundOn ? 'Ambience on' : 'Add ambience'}</button>
            </div>
          </div>
          {mood.timer && <div className="timer-card">
            <div className="timer-label"><span>{selected === 'focused' ? 'deep focus' : 'soft timer'}</span><span>{selected === 'focused' ? '25 min' : 'reset anytime'}</span></div>
            <div className="timer-time">{formatTime(timeLeft)}</div>
            <div className="timer-progress"><span style={{ width: `${mood.timer ? Math.max(0, (timeLeft / mood.timer) * 100) : 0}%` }} /></div>
            <div className="timer-controls"><button onClick={() => setIsPlaying((playing) => !playing)} aria-label={isPlaying ? 'Pause timer' : 'Start timer'}>{isPlaying ? <Pause size={16} /> : <Play size={16} />}</button><button onClick={resetTimer} aria-label="Reset timer"><RotateCcw size={16} /></button></div>
          </div>}
          <div className="scene-caption"><span className="caption-icon">{selected === 'focused' ? <Wind size={17} /> : selected === 'energetic' ? <Zap size={17} /> : selected === 'calm' ? <Waves size={17} /> : <Cloud size={17} />}</span><span>stay here as long as you need</span></div>
        </section>
      )}
    </main>
  )
}

function SceneDecor({ mood }: { mood: MoodId }) {
  if (mood === 'focused') return <div className="focus-desk" aria-hidden="true"><div className="desk-lamp" /><div className="desk-line" /></div>
  if (mood === 'sleepy') return <div className="sleepy-sky" aria-hidden="true"><div className="moon" /><div className="stars">{Array.from({ length: 24 }).map((_, i) => <i key={i} style={{ '--i': i } as React.CSSProperties} />)}</div><div className="cloud cloud-one" /><div className="cloud cloud-two" /></div>
  if (mood === 'happy') return <div className="happy-sky" aria-hidden="true">{Array.from({ length: 12 }).map((_, i) => <i key={i} style={{ '--i': i } as React.CSSProperties}>{i % 3 === 0 ? '✦' : i % 3 === 1 ? '○' : '◇'}</i>)}</div>
  return <div className={`particles particles-${mood}`} aria-hidden="true">{Array.from({ length: mood === 'energetic' ? 32 : 22 }).map((_, i) => <i key={i} style={{ '--i': i } as React.CSSProperties} />)}</div>
}
